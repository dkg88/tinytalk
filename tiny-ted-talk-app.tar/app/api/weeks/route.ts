import { list } from '@vercel/blob';
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const { blobs } = await list({ prefix: 'weeks/' });

    // Group by week
    const weekMap: Record<string, { url: string; type: string }[]> = {};

    for (const blob of blobs) {
      // pathname like: weeks/2025-02-23/image_123.jpg
      const parts = blob.pathname.split('/');
      if (parts.length >= 3) {
        const weekKey = parts[1];
        if (!weekMap[weekKey]) weekMap[weekKey] = [];
        weekMap[weekKey].push({
          url: blob.url,
          type: blob.pathname.includes('video_') ? 'video' : 'image',
        });
      }
    }

    // Build week list
    const weeks = Object.entries(weekMap)
      .map(([weekKey, items]) => ({
        weekKey,
        label: getWeekLabel(weekKey),
        items,
      }))
      .sort((a, b) => b.weekKey.localeCompare(a.weekKey));

    return NextResponse.json({ weeks });
  } catch (error) {
    console.error('Weeks error:', error);
    return NextResponse.json({ weeks: [] });
  }
}

function getWeekLabel(weekKey: string): string {
  const start = new Date(weekKey + 'T00:00:00');
  const end = new Date(start);
  end.setDate(start.getDate() + 6);
  const opts: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric' };
  return `Week of ${start.toLocaleDateString('en-US', opts)} – ${end.toLocaleDateString('en-US', opts)}`;
}
