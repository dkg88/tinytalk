import { list } from '@vercel/blob';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const pin = searchParams.get('pin');
  const week = searchParams.get('week');

  // PIN check
  if (pin !== undefined && pin !== null) {
    const correctPin = process.env.APP_PIN || '1234';
    if (pin !== correctPin) {
      return NextResponse.json({ error: 'Invalid PIN' }, { status: 401 });
    }
    return NextResponse.json({ ok: true });
  }

  // List photos for a week
  const weekKey = week || getWeekKey();
  const prefix = `weeks/${weekKey}/`;

  try {
    const { blobs } = await list({ prefix });

    const items = blobs.map(blob => ({
      url: blob.url,
      pathname: blob.pathname,
      type: blob.pathname.includes('video_') ? 'video' : 'image',
      uploadedAt: blob.uploadedAt,
      size: blob.size,
    }));

    // Sort by upload time
    items.sort((a, b) => new Date(a.uploadedAt).getTime() - new Date(b.uploadedAt).getTime());

    return NextResponse.json({ items });
  } catch (error) {
    console.error('List error:', error);
    return NextResponse.json({ items: [] });
  }
}

function getWeekKey(): string {
  const now = new Date();
  const d = new Date(now);
  d.setDate(d.getDate() - d.getDay());
  d.setHours(0, 0, 0, 0);
  return d.toISOString().split('T')[0];
}
